# Orbital Remediation Roadmap

This roadmap follows the 12 November 2026 review of `develop` at `2d58bd1`. It targets an accurate, repeatable academic demonstration. Effort estimates are implementation plus focused testing for one engineer: S = up to one day, M = one to three days, L = three to five days. They exclude external approval delays. No fixes have been implemented.

## First establish safe and repeatable validation

| Order | Work | Findings | Effort | Dependency | Acceptance |
| --- | --- | --- | --- | --- | --- |
| 1 | Restrict default service bindings and administration access; exclude sensitive files from Docker contexts | F01, F14 | S | None | Internal ports private or loopback-only; default setup cannot expose admin credentials to the LAN; harmless excluded sentinel files absent from build context; images still build. |
| 2 | Make check tasks read-only and repair the combined documentation task graph | F12 | S | None | Misformatting fails without rewriting source; clean check and docs tasks work together. |
| 3 | Establish effective CI merge requirements and publish only validated artifacts | F11 | M | Step 2 | Named test checks required in effective GitHub settings; failed checks block the intended merge path; shared Gradle changes rebuild images; ingestor and intended release tags published from validated SHA. Verify legacy protections before changing settings. |

## Then correct integration and data integrity

| Order | Work | Findings | Effort | Dependency | Acceptance |
| --- | --- | --- | --- | --- | --- |
| 4 | Correct trusted client identity at Nginx and gateway; separate operational probes from user quotas | F02 | M | Step 1 | Independent client quotas; spoofed headers ineffective; liveness usable during client exhaustion; Redis outage policy explicit. |
| 5 | Give Sentinel persistent writable directories; namespace service cache entries | F03, F15 | M | None | Config rewrites succeed; promotion and client recovery work; Sentinel restart retains topology; gateway/news caches coexist. |
| 6 | Bound dependency waits and standardize failure responses and readiness | F04 | M | Step 4 for probe behavior | Refusal, timeout, 429, and DB outage yield safe structured errors within defined deadlines; readiness degrades and recovers correctly; full clients show understandable errors. |
| 7 | Make batch semantics and backfill completion explicit; add PostgreSQL integration coverage | F06, F07 | M–L | Step 6 for truthful failure reporting | Mixed batches have documented outcomes; row counts/logs agree; live data does not mark backfill complete; restarts retry partial backfills; duplicate observations and history retention are handled. |
| 8 | Preserve real timestamps through the history API and chart rendering | F05 | M | Step 7 defines observation/deduplication semantics | Irregular timestamps survive storage/API/client rendering; reload does not move history in time; fallback data is labeled. |

## Improve client behavior and maintainability

| Order | Work | Findings | Effort | Dependency | Acceptance |
| --- | --- | --- | --- | --- | --- |
| 9 | Stabilize list identity and price precision | F08, F10 | S–M | None | Filtering/reordering cannot transfer expansion; sub-cent prices stay nonzero; JVM and Wasm formatter checks agree. |
| 10 | Model freshness and refresh failures independently of loaded content | F09 | M | Step 6 simplifies error handling | Success then outage shows stale status and retry; recovery clears it; overlapping requests cannot overwrite newer state; cancellation propagates. |
| 11 | Complete empty states, accessibility labels, chart alternatives, and news actions | F16 | M | Steps 8–10 | Search and expansion are understandable without visual inference; empty states guide recovery; keyboard journeys pass; screen-reader results documented; article action opens the expected URL. |
| 12 | Reconcile configuration, architecture, and mock/demo documentation | F17 | S | Steps 4–11 define final behavior | Clean setup matches the docs; documented env settings reach the process; full/demo distinctions and mocked categories are explicit; dangling references removed. |

## Dependency maintenance and optional hardening

Run dependency maintenance (F13, M) alongside steps 2–3. Capture the resolved dependency inventory, assess current maintainer advisories, update compatible releases, and add an automated advisory/update workflow. Do not unify client and backend Ktor merely to reduce version count. Accept upgrades only after backend, browser, desktop, image, and documentation checks pass.

As part of touched code, give HTTP clients/pools clear shutdown ownership and move blocking Redis work away from event-loop handlers. Add targeted lifecycle and cancellation tests where behavior changes. Do not introduce repositories, interfaces, or layers solely to satisfy a style rule.

For a later public deployment, separately assess TLS, secrets distribution, non-root containers and resource limits, backup restoration, alerting, observability during limiter degradation, dependency/image signing, and infrastructure ownership. Authentication should follow actual access-control requirements; public read-only market data does not by itself require a login. PostgreSQL automatic failover and native installer distribution are separate scope decisions, not prerequisites for the academic demo.

## Interface and compatibility decisions

The principal recommended API change is timestamped market-history points. If there are consumers outside this repository, introduce a versioned endpoint or an additive representation while retaining the existing price-array endpoint during migration. If all consumers are controlled here, update backend and both clients in one coordinated change and document the contract. Define ascending order and timestamp units explicitly.

Keep existing success envelopes stable while standardizing error envelopes. Separate liveness from readiness without silently changing the meaning of existing health consumers. Migration work for backfill status or uniqueness must preserve existing snapshots and include an upgrade test against an already populated database.

Before claiming remediation complete, rerun the reproductions in the review and require every confirmed finding to be either fixed with evidence or explicitly accepted with a recorded rationale. Publish no artifact based only on a successful build; require the corresponding validation results.
