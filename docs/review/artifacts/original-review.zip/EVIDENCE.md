# Orbital Review Evidence

Baseline commit: `2d58bd1d9e51fba8955d3b6cd582b7e04bbdb9ca`, reviewed 12 November 2026.

Start with REVIEW.md and ROADMAP.md. Findings link to exact source locations and command evidence. Source and generated app distributions are retained separately under /tmp/orbital-review; they are omitted from this compact evidence bundle. No academic report material is included in the bundle.

The review source was created with git archive HEAD. Only report-related local changes existed, and those were excluded from review. Docker configuration was copied to compose.review.yml, fixed container names removed, published ports rebound to 127.0.0.1 with review-specific port numbers, credentials replaced with disposable values, and images named orbital-review-*. The ingestor used an opt-in profile to limit external calls. These isolation edits are not proposed fixes.

## Main commands

- `CHROME_BIN=<installed-chromium> ./gradlew --no-daemon check`
- `./gradlew --no-daemon dokkaHtmlMultiModule :orbital-app:wasmJsBrowserDistribution -PorbitalDemoBuild=true`
- `./gradlew --no-daemon :orbital-app:wasmJsBrowserDistribution :orbital-app:desktopJar`
- `docker compose -p orbital-review -f compose.review.yml build`
- `docker compose -p orbital-review -f compose.review.yml --profile ingestion build market-ingestor`
- `./gradlew --no-daemon :market-service:dependencies --configuration runtimeClasspath`

The combined checks/artifacts/docs invocation in gradle-validation.log intentionally exposed the task dependency failure. Later separate builds and final-check.log establish successful supported invocations.

runtime.py records local HTTP, cache, transaction, and replication checks. failures.py operates only on disposable review containers and records dependency outages. ui.cjs and full-ui.cjs serve the actual built client and use synthetic upstream responses in Chromium. Their machine-specific Playwright path and port numbers must be adapted when reproducing elsewhere. Never run failure scripts against a production Compose project.

Cleanup removed review containers, network, and volumes. Review images and build caches remain available. The original repository working-tree status was identical before and after the review; see evidence/preservation.json.

## Limits

Some initial JVM tests came from Gradle cache; browser tests were rerun with Chromium explicitly configured. UI screenshots contain synthetic sample prices, not a market-data record. Error/timeout evidence is scoped to local tests. No production penetration test, screen-reader certification, native installer validation, exhaustive advisory scan, or full secret-history scan was performed.
