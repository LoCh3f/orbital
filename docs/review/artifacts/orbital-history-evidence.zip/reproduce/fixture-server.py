from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import json, time, math
DIST='/home/aldo/project/orbital/orbital-app/build/dist/wasmJs/productionExecutable'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=DIST,**kwargs)
    def do_GET(self):
        parsed=urlparse(self.path)
        if not parsed.path.startswith('/api/'):
            return super().do_GET()
        params=parse_qs(parsed.query)
        now=int(time.time())
        if parsed.path.endswith('/prices'):
            data=[dict(coinId='bitcoin',symbol='BTC',name='Bitcoin',currentPriceUsd=65000.0,marketCapUsd=1000000000.0,volume24hUsd=300000.0,priceChangePercent24h=2.3,lastUpdated='2026-11-13T08:00:00Z',sparklineIn7d=[10,20,15,25,20,35,30])]
        elif '/history-range/' in parsed.path:
            rg=params.get('range',['all'])[0]
            source=params.get('source',['auto'])[0]
            source='binance' if source=='auto' else source
            duration={'24h':86400,'7d':604800,'1m':2592000,'1y':31536000,'all':now-1503014399}[rg]
            start=int(params.get('from',[now-duration])[0]); end=int(params.get('to',[now])[0])
            step=next(s for s in [300,900,3600,14400,86400,604800,2592000] if (end-start)//s<=1500)
            points=[dict(timestamp=t,price=10000+i*20+math.sin(i/7)*700) for i,t in enumerate(range(start,end+1,step)) if not 30<=i<=35]
            data=dict(coinId='bitcoin',source=source,quote='USDT' if source=='binance' else 'USD',pair='BTCUSDT' if source=='binance' else None,points=points,from_=start,to=end,resolutionSeconds=step,earliestAvailable=1503014399,latestAvailable=now,gaps=[dict(from_=start+30*step,to=start+35*step)],importing=False,binanceAvailable=True)
            data['from']=data.pop('from_');data['gaps'][0]['from']=data['gaps'][0].pop('from_')
            with open('/tmp/orbital-history-browser-requests.jsonl','a') as f: f.write(json.dumps(dict(path=parsed.path,params=params,step=step))+'\n')
        else: data=[]
        body=json.dumps(dict(data=data)).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*args): pass
ThreadingHTTPServer(('127.0.0.1',8080),Handler).serve_forever()
