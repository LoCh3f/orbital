import com.orbital.market.history.*;
import com.orbital.market.persistence.MarketRepository;
import java.time.Instant;
import java.util.*;
public class OrbitalHistorySmoke {
  public static void main(String[] args) throws Exception {
    MarketRepository.INSTANCE.initDatabase("jdbc:postgresql://127.0.0.1:55439/history_test", "history_test", "history_test");
    try {
      HistoryRepository.INSTANCE.track(List.of("bitcoin"), Map.of("bitcoin",new kotlin.Pair<>("BTC","Bitcoin")));
      var archive = new BinanceArchive(new PublicArchiveTransport());
      var files = archive.files("BTCUSDT","1d",Instant.parse("2017-08-01T00:00:00Z").getEpochSecond(),Instant.parse("2017-08-31T23:59:59Z").getEpochSecond());
      if (files.size()!=1) throw new AssertionError("Expected one monthly archive, got "+files.size());
      var data = archive.download(files.getFirst());
      HistoryRepository.INSTANCE.saveArchive("bitcoin","BTCUSDT",86400,files.getFirst(),data.getFirst(),data.getSecond());
      HistoryRepository.INSTANCE.saveArchive("bitcoin","BTCUSDT",86400,files.getFirst(),data.getFirst(),data.getSecond());
      var result=HistoryQueries.INSTANCE.query("bitcoin","binance",null,null,"all",Instant.now().getEpochSecond());
      if(result.getPoints().size()!=15 || !result.getQuote().equals("USDT")) throw new AssertionError("Archive persistence mismatch");
      if(result.getEarliestAvailable()!=1503014399L) throw new AssertionError("Wrong earliest date");
      if(!HistoryRepository.INSTANCE.imported(files.getFirst())) throw new AssertionError("Missing durable ledger");
      System.out.println("HISTORY_SMOKE_OK points="+result.getPoints().size()+" earliest="+result.getEarliestAvailable()+" quote="+result.getQuote()+" checksum="+data.getFirst());
    } finally { MarketRepository.INSTANCE.close(); }
  }
}
