const {chromium}=require('/home/aldo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const root=process.argv[2]||'/tmp/orbital-review/demo';
const out='/tmp/orbital-review/evidence';
const server=http.createServer((req,res)=>{let p=path.join(root,decodeURIComponent(req.url.split('?')[0]));if(req.url==='/')p=path.join(root,'index.html');try{let b=fs.readFileSync(p);res.setHeader('Content-Type',p.endsWith('.wasm')?'application/wasm':p.endsWith('.js')?'text/javascript':p.endsWith('.html')?'text/html':'application/octet-stream');res.end(b)}catch(e){res.statusCode=404;res.end()}});

(async()=>{server.listen(38090,'127.0.0.1');const b=await chromium.launch({headless:true});const p=await b.newPage({viewport:{width:390,height:844}});const logs=[];p.on('pageerror',e=>logs.push(String(e)));
let fail=false,requests=[];
const data=[{coinId:'bitcoin',symbol:'BTC',name:'Bitcoin',currentPriceUsd:72300,marketCapUsd:1.4e12,volume24hUsd:2.5e10,priceChangePercent24h:2.35,lastUpdated:'2026-11-12T14:00:00Z',sparklineIn7d:[71000,71500,71200,72300],logoUrl:''},{coinId:'tiny',symbol:'TINY',name:'Tiny Token',currentPriceUsd:0.00001234,marketCapUsd:100000,volume24hUsd:1200,priceChangePercent24h:-3.1,lastUpdated:'2026-11-12T14:00:00Z',sparklineIn7d:[0.000014,0.000013,0.00001234],logoUrl:''}];
await p.route('http://127.0.0.1:8080/**',r=>{const u=new URL(r.request().url());requests.push(u.pathname+u.search);let payload=u.pathname.includes('/news')?[{id:'test',title:'Example news headline',description:'Test article for UI review',url:'https://example.com/article',sourceName:'Orbital Mock',publishedAt:'2024-01-01T12:00:00Z',category:u.searchParams.get('category')||'CRYPTO'}]:u.pathname.includes('/history')?[71000,72000,72300]:data;return r.fulfill({status:fail?503:200,contentType:'application/json',headers:{'access-control-allow-origin':'*'},body:JSON.stringify(fail?{code:503,message:'Review outage'}:{data:payload})})});
async function clickRole(role,name){let box=await p.getByRole(role,{name,exact:true}).first().boundingBox();if(!box)throw new Error('missing '+name);await p.mouse.click(box.x+box.width/2,box.y+box.height/2);await p.waitForTimeout(400)}
await p.goto('http://127.0.0.1:38090');await p.waitForTimeout(4000);console.log('initial',await p.locator('body').ariaSnapshot());await p.screenshot({path:out+'/full-initial.png'});
await clickRole('button',/BTC BTC/);await p.waitForTimeout(600);await p.screenshot({path:out+'/full-expanded.png'});
await p.mouse.click(150,100);await p.keyboard.type('tiny');await p.waitForTimeout(500);console.log('filtered',await p.locator('body').ariaSnapshot());await p.screenshot({path:out+'/full-filtered.png'});
await clickRole('button','News');console.log('news',await p.locator('body').ariaSnapshot());await p.screenshot({path:out+'/full-news.png'});
await clickRole('button','TECH');await p.waitForTimeout(600);console.log('category',await p.locator('body').ariaSnapshot());
await clickRole('button','Market');console.log('preserved search',await p.locator('body').ariaSnapshot());
await p.mouse.click(150,100);await p.keyboard.press('Control+A');await p.keyboard.press('Backspace');await p.keyboard.press('Tab');console.log('keyboard focus',await p.evaluate(()=>({tag:document.activeElement.tagName,role:document.activeElement.getAttribute('role')})));
fail=true;await p.waitForTimeout(31000);await p.screenshot({path:out+'/full-stale.png'});console.log('stale',await p.locator('body').ariaSnapshot());console.log('requests',requests);console.log('errors',logs);await b.close();server.close();})();
