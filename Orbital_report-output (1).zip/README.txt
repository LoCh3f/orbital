Orbital project report - reviewed 16 November 2026

Open report/main.pdf to read the report.
The single canonical LaTeX source is report/main.tex.
The implementation baseline is develop e763ad4 / main c5e362f (version 1.3.0).
Validation evidence described in the report belongs to the project repository;
this standalone bundle contains the report sources and rendered figures only.

To rebuild, install Tectonic or latexmk with a TeX distribution, then run:
  make -C report pdf
The first build may download standard TeX packages and fonts.
Existing PNG figures are included, so Mermaid is not required for a PDF build.
To regenerate edited Mermaid diagrams, install Mermaid CLI 11.16.0 and Chromium:
  make -C report diagrams
Set PUPPETEER_EXECUTABLE_PATH if using an existing Chromium installation.
