import urllib.request,urllib.error,json,subprocess,time,socket
from pathlib import Path
base=['docker','compose','-p','orbital-review','-f','/tmp/orbital-review/source/compose.review.yml']
def dc(*a):return subprocess.run(base+list(a),capture_output=True,text=True,timeout=90).stdout.strip()
def get(port,path,headers=None):
 try:
  r=urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}{path}',headers=headers or {}),timeout=35)
 except urllib.error.HTTPError as e:r=e
 except Exception as e:return {'error':str(e)}
 body=r.read().decode();return {'status':r.status,'headers':dict(r.headers),'body':body[:2000]}
def redis(*a):return dc('exec','-T','redis','redis-cli','--raw',*a)
def emit(label,result):print(json.dumps({'check':label,'result':result}),flush=True)
for p in [38080,38081,38082]:emit('health '+str(p),get(p,'/health'))
emit('market live',get(38080,'/api/v1/market/prices',{'X-Request-Id':'orbital-review-trace'}))
emit('news live',get(38080,'/api/v1/news?category=CRYPTO'))
emit('gateway cache format',redis('GET','news:category:CRYPTO')[:100])
emit('direct news',get(38082,'/api/v1/news?category=CRYPTO'))
emit('service cache format',redis('GET','news:category:CRYPTO')[:100])
emit('gateway after direct service',get(38080,'/api/v1/news?category=CRYPTO'))
for path in ['/api/v1/market/history/bitcoin','/api/v1/news/history','/api/v1/news?category=INVALID','/api/v1/market/history/bad%27id']:
 emit(path,get(38080,path))
emit('default arbitrary CORS',get(38080,'/health',{'Origin':'https://untrusted.example'}))
for name,user,db in [('postgres-market','market_user','market_data'),('postgres-news','news_user','news_data')]:
 emit(name+' streaming',dc('exec','-T',name,'psql','-U',user,'-d',db,'-Atc','select state from pg_stat_replication'))
 emit(name+' row counts',dc('exec','-T',name,'psql','-U',user,'-d',db,'-Atc','select count(*) from '+('market_prices' if name=='postgres-market' else 'news')))
emit('prometheus targets',get(39090,'/api/v1/targets'))
# Exhaust only cheap local health endpoint, changing untrusted XFF does not bypass default.
counts={}
for i in range(65):
 r=get(38080,'/health',{'X-Forwarded-For':f'198.51.100.{i+1}'}); k=str(r.get('status',r.get('error')));counts[k]=counts.get(k,0)+1
emit('65 health calls varying XFF',counts)
emit('rate counter keys',redis('KEYS','ratelimit:*'))
emit('health after exhaustion',get(38080,'/health'))
emit('direct news bypass gateway limiter',get(38082,'/health'))
# SQL-level reproduction of the same catch-and-continue transaction semantics.
sql="CREATE TEMP TABLE review_batch (symbol varchar(2)); BEGIN; INSERT INTO review_batch VALUES ('OK'); INSERT INTO review_batch VALUES ('TOO_LONG'); INSERT INTO review_batch VALUES ('OK'); COMMIT; SELECT count(*) FROM review_batch;"
p=subprocess.run(base+['exec','-T','postgres-market','psql','-U','market_user','-d','market_data'],input=sql,text=True,capture_output=True)
emit('Postgres mixed batch transaction',{'stdout':p.stdout,'stderr':p.stderr})
Path('/tmp/orbital-review/evidence/stack-logs.txt').write_text(dc('logs','--no-color','--tail','120'))
