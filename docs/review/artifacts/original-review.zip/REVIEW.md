# Orbital Security and Engineering Review

Reviewed 12 November 2026 for academic engineering quality. Baseline: `develop`, commit `2d58bd1d9e51fba8955d3b6cd582b7e04bbdb9ca`.

Orbital builds and demonstrates its main data flows, but green unit tests do not cover several integration and user-facing failures. The highest priorities are restricting the default network exposure and correcting client identity at the proxy. Reliability and data-integrity work should then address Sentinel persistence, error handling, and historical chart accuracy before cosmetic refactoring.

The review covers services, shared libraries, clients, infrastructure, CI/CD, and repository documentation. Academic report drafts, report assets, and archives were excluded. All non-report working files matched the baseline; validation ran in `/tmp/orbital-review/source`. The original working tree was preserved. No fixes, commits, pushes, deployments, or repository-setting changes were made.

## Architecture and strengths

The full desktop/web client calls Nginx, which proxies to the gateway. The gateway routes to market and news services and shares Redis/Sentinel with news caching and rate limiting. Services write separate PostgreSQL primaries with streaming standbys. The market worker also writes snapshots. The demo web build calls CoinGecko directly and omits news. Prometheus scrapes the services and Grafana supplies dashboards.

Useful foundations include separated service modules, injectable HTTP/cache collaborators, typed DTOs and mappers, bounded in-memory caching, parameterized persistence queries, application-scoped background jobs, request-ID propagation, and regression tests for proxy headers and retained UI search state. The intentional separation of backend and WebAssembly-compatible client dependencies is reasonable. Native chart rendering also legitimately differs from web rendering; uniform implementation is not itself a quality goal.

## Validation results

| Check | Result and evidence |
| --- | --- |
| Standard Gradle check | Passed with `CHROME_BIN` set to the installed Chromium. The first attempt lacked browser discovery; this was an environment issue. See [final check log](evidence/final-check.log). |
| Existing tests | 59 test executions, zero failures/errors/skips across backend, shared libraries, desktop, and browser suites. Common tests run on both targets, so this is not 59 unique behaviors. Some initial backend results came from Gradle cache. See [test inventory](evidence/tests.json). |
| Full and demo web builds | Both passed; [full build](evidence/full-app-build.log), [demo and docs build](evidence/demo-docs-build.log). |
| Desktop artifact and UI tests | Desktop JAR and two Compose UI tests passed. Native installers and a manual desktop-window walkthrough were not verified. |
| API documentation | Passed separately. Combined check/docs task graph fails, documented in F12. |
| Service images | Gateway, market, news, and ingestor built from the snapshot; [service image log](evidence/docker-build.log), [worker image log](evidence/ingestor-build.log). |
| Local integration | All three health endpoints, live market data, mocked news, persistence, history reads, request IDs, and Prometheus targets worked. Both PostgreSQL primaries reported streaming replicas. [Runtime evidence](evidence/runtime.jsonl). |
| Ingestion | Worker logged 20 persisted snapshots in a single observed polling cycle, then was stopped. Backfill completion was not established. [Worker log](evidence/ingestor-runtime.log). |
| Failure scenarios | Exercised rate-limit exhaustion, forged forwarding headers under default settings, arbitrary-origin CORS, malformed inputs, DB outage, upstream refusal, and Redis interruption. [Failure evidence](evidence/failures.jsonl). |
| Browser UI | Actual full/demo builds inspected at 1280×900 and/or 390×844 with controlled responses. Verified rendering, search, expansion, filters, error/retry and stale-data behavior. See [demo log](evidence/ui.log) and [full client log](evidence/full-ui.log). |
| CI and GitHub settings | Current-commit Test & Lint run passed. Active main ruleset inspected; legacy branch-protection details returned 403. [GitHub evidence](evidence/github.json). |
| Secrets and advisories | Limited current-file scan found no private-key blocks, GitHub token patterns, or AWS access-key patterns. Resolved runtime versions checked against selected maintainer advisories. Not a full history, entropy, container, or dependency vulnerability scan. |

Infrastructure validation used a separate Compose project, loopback ports, disposable credentials/volumes, and review-specific image names. These changes prevented collisions and are not evidence that the checked-in network bindings are safe. UI market/news fixtures were synthetic; the separate integration test fetched real market data. PostgreSQL automatic failover is explicitly absent from the repository and is not counted as a missing academic requirement.

## Prioritized findings

High means an important security boundary or shared availability failure under the documented setup. Medium means material correctness, reliability, delivery, or maintainability impact. Low means a narrower usability, efficiency, or documentation issue. These are contextual review severities, not CVSS scores. No critical exploit was demonstrated.

| ID | Severity | Finding |
| --- | --- | --- |
| F01 | High | The local stack exposes internal services and administration ports |
| F02 | High | Nginx clients share one rate limit bucket |
| F03 | Medium | Sentinel cannot persist configuration through its file mounts |
| F04 | Medium | Dependency failures lack bounded and consistent API responses |
| F05 | Medium | History charts display fabricated times |
| F06 | Medium | One invalid row can roll back a whole persistence batch |
| F07 | Medium | Live snapshots incorrectly mark historical backfill as complete |
| F08 | Medium | Expanded row state moves to a different coin after filtering |
| F09 | Medium | Failed refreshes leave old data looking current |
| F10 | Medium | Small nonzero market prices are shown as zero |
| F11 | Medium | CI success is not consistently required for merge and publication |
| F12 | Medium | Validation invokes formatters and conflicts with documentation generation |
| F13 | Medium | Runtime dependencies include versions covered by security advisories |
| F14 | Medium | Docker sends the entire checkout into builder layers |
| F15 | Low | Gateway and news cache entries overwrite each other |
| F16 | Low | UI feedback and accessibility semantics are incomplete |
| F17 | Low | Documentation and configuration promises diverge from the running app |

### F01 The local stack exposes internal services and administration ports

**High severity · High confidence.** [docker-compose.yml:58](/home/aldo/project/orbital/docker-compose.yml:58), [docker-compose.yml:219](/home/aldo/project/orbital/docker-compose.yml:219), [docker-compose.yml:311](/home/aldo/project/orbital/docker-compose.yml:311)

Compose publishes database, Redis, direct service, monitoring, and admin ports without a loopback bind. Database and admin passwords have committed fallback values. Direct service access bypassed the exhausted gateway limiter in the isolated runtime test. The review deliberately rebound these ports to loopback and used disposable credentials.

**Impact:** Running the documented local setup can expose internal interfaces to other reachable hosts, depending on host firewall/routing. This is a local-development default problem, not merely future production hardening. No unauthorized remote access was attempted.

**Remedy:** Bind necessary developer ports to 127.0.0.1; keep internal services unpublished by default; put administration tools behind an explicit development profile. Require non-default credentials for any network-accessible deployment.

**Acceptance:** Inspect resolved Compose bindings and test that only intended ingress is externally reachable; verify application paths through the gateway. Preserve an explicit local debugging option.

### F02 Nginx clients share one rate limit bucket

**High severity · High confidence.** [gateway/src/main/kotlin/com/orbital/gateway/App.kt:96](/home/aldo/project/orbital/gateway/src/main/kotlin/com/orbital/gateway/App.kt:96), [docker-compose.yml:14](/home/aldo/project/orbital/docker-compose.yml:14), [nginx/gateway-lb.conf:26](/home/aldo/project/orbital/nginx/gateway-lb.conf:26)

[runtime.jsonl](evidence/runtime.jsonl): 65 cheap health requests with different X-Forwarded-For values produced 51 successes and 14 rejections after earlier requests. Redis recorded the Nginx container hostname as the client key. The next public health request also returned 429. Compose does not enable TRUST_PROXY_HEADERS.

**Impact:** Every user behind the load balancer consumes the same 60-request budget. A single client can deny service to the others. Simply enabling proxy trust is unsafe because Nginx currently appends client-supplied forwarding headers.

**Remedy:** Make Nginx overwrite forwarding identity, explicitly trust only that ingress path, and ensure gateway ports remain private. Separate liveness/readiness from public request quotas; document degraded limiter behavior during Redis loss.

**Acceptance:** Two distinct client addresses must have independent budgets through Nginx; forged forwarding headers must not change identity; health must remain usable after a client exhausts its quota.

### F03 Sentinel cannot persist configuration through its file mounts

**Medium severity · High confidence.** [docker-compose.yml:253](/home/aldo/project/orbital/docker-compose.yml:253), [redis/sentinel-1.conf:2](/home/aldo/project/orbital/redis/sentinel-1.conf:2)

[stack-logs.txt](evidence/stack-logs.txt) and [failure-stack-logs.txt](evidence/failure-stack-logs.txt): all three Sentinels repeatedly logged “Could not rename tmp config file (Resource busy)”. Each configuration is bind-mounted as a single file. A 12-second outage probe still reported the old master; TILT mode and DNS failures occurred, so that short probe does not establish a definitive failover deadline.

**Impact:** The configuration is writable in place but cannot be replaced by Sentinel’s atomic rename. Sentinel identity, topology, and election state cannot be reliably persisted across restarts.

**Remedy:** Seed a separate writable directory or volume for each Sentinel, then run it from a file inside that directory. Keep seed files read-only and runtime state outside source control.

**Acceptance:** Require successful config rewrites, a controlled promotion, client reconnection, and restart of all Sentinels with the promoted master retained. Repeat without TILT mode before claiming failover timing.

### F04 Dependency failures lack bounded and consistent API responses

**Medium severity · High confidence.** [gateway/src/main/kotlin/com/orbital/gateway/Routing.kt:156](/home/aldo/project/orbital/gateway/src/main/kotlin/com/orbital/gateway/Routing.kt:156), [market-service/src/main/kotlin/com/orbital/market/plugins/Routing.kt:152](/home/aldo/project/orbital/market-service/src/main/kotlin/com/orbital/market/plugins/Routing.kt:152), [libs/core/src/main/kotlin/com/orbital/plugins/Monitoring.kt:20](/home/aldo/project/orbital/libs/core/src/main/kotlin/com/orbital/plugins/Monitoring.kt:20)

[failures.jsonl](evidence/failures.jsonl): stopping market-service produced an empty gateway 500; gateway health remained 200. With PostgreSQL stopped, market health remained 200 while history exceeded the 35-second client timeout. Logs show a 30-second pool-acquisition timeout and transaction retry. Service handlers also return exception messages to callers.

**Impact:** Clients cannot reliably decode the advertised error envelope or distinguish unavailable dependencies from application defects. Liveness alone gives no readiness signal, and internal database details can enter API errors.

**Remedy:** Add bounded HTTP/database deadlines, centralized sanitized error mapping, and distinct liveness/readiness endpoints. Return structured 502/503/504 responses as appropriate, retain details only in correlated logs, and teach full-client API adapters to decode error envelopes.

**Acceptance:** Inject connection refusal, slow upstream, provider 429, and DB outage; assert a bounded response time, stable envelope, safe message, request ID, and truthful readiness. Verify recovery after restart.

### F05 History charts display fabricated times

**Medium severity · High confidence.** [market-service/src/main/kotlin/com/orbital/market/persistence/MarketRepository.kt:102](/home/aldo/project/orbital/market-service/src/main/kotlin/com/orbital/market/persistence/MarketRepository.kt:102), [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/PriceChart.kt:71](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/PriceChart.kt:71), [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:261](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:261)

The database stores observation times but the history API returns List<Double>. The web renderer assigns every sample an hourly interval ending at browser time. The same renderer handles minute-based ingestion and irregular backfilled history. The expanded chart visibly presents these synthetic times.

**Impact:** A data visualization communicates an incorrect time range and sampling interval. Reloading shifts the historical axis even when the observations have not changed.

**Remedy:** Carry actual observation timestamps through a typed history-point DTO and render them directly. If upstream sparkline times remain approximate, use an explicitly relative axis and identify the approximation. Label history versus sparkline fallback.

**Acceptance:** Use irregularly spaced historical fixtures and assert exact time/value pairs; reloading must not shift stored observations. Check ordering, duplicate timestamps, missing history, and desktop/web equivalence.

### F06 One invalid row can roll back a whole persistence batch

**Medium severity · High confidence.** [market-service/src/main/kotlin/com/orbital/market/persistence/MarketRepository.kt:74](/home/aldo/project/orbital/market-service/src/main/kotlin/com/orbital/market/persistence/MarketRepository.kt:74), [news-service/src/main/kotlin/com/orbital/news/persistence/NewsRepository.kt:77](/home/aldo/project/orbital/news-service/src/main/kotlin/com/orbital/news/persistence/NewsRepository.kt:77), [market-service/src/test/kotlin/com/orbital/market/persistence/MarketRepositoryTest.kt:50](/home/aldo/project/orbital/market-service/src/test/kotlin/com/orbital/market/persistence/MarketRepositoryTest.kt:50)

Both repositories catch individual insert failures inside one transaction. [runtime.jsonl](evidence/runtime.jsonl) reproduces PostgreSQL semantics with valid/invalid/valid inserts: subsequent statements are aborted and COMMIT rolls back, leaving zero rows. Existing tests explicitly use H2, whose behavior differs. This is a SQL-level reproduction plus source tracing, not a new Kotlin integration test.

**Impact:** Best-effort persistence can lose otherwise valid rows while callers continue normally; ingestion success logging can overstate durable writes.

**Remedy:** Choose and document atomic-batch failure or partial acceptance. For atomic batches, propagate failure; for partial acceptance, validate first or use savepoints/separate transactions. Return a persisted-row result and test against PostgreSQL.

**Acceptance:** Run valid/invalid/valid batches against real PostgreSQL and assert the chosen semantics, row counts, and truthful logs for both repositories.

### F07 Live snapshots incorrectly mark historical backfill as complete

**Medium severity · High confidence.** [market-service/src/main/kotlin/com/orbital/market/MarketIngestor.kt:86](/home/aldo/project/orbital/market-service/src/main/kotlin/com/orbital/market/MarketIngestor.kt:86), [market-service/src/main/kotlin/com/orbital/market/plugins/Routing.kt:83](/home/aldo/project/orbital/market-service/src/main/kotlin/com/orbital/market/plugins/Routing.kt:83)

The backfill guard tests for any stored row. Fetching prices inserts snapshots before the worker starts; in [ingestor-runtime.log](evidence/ingestor-runtime.log) the worker then proceeds to polling and logs 20 new snapshots. Failed backfills followed by a successful polling cycle likewise make later restarts skip backfill.

**Impact:** The promised longer history depends on startup order and may never be populated. API reads and the worker both append observations, and a 500-row cap is a sample limit rather than a guaranteed long time range.

**Remedy:** Record backfill completion separately from live observations, retry incomplete work, and define one ingestion ownership/deduplication policy. Define history range/downsampling independently of raw row count.

**Acceptance:** Test API-before-worker startup, partial backfill failure then restart, duplicate timestamps, and a database with more than 500 minute samples. Only a completed historical import should suppress backfill.

### F08 Expanded row state moves to a different coin after filtering

**Medium severity · High confidence.** [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:157](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:157), [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:190](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:190)

[full-filtered.png](evidence/full-filtered.png) and [full-ui.log](evidence/full-ui.log): expanding Bitcoin and then filtering to Tiny Token leaves Tiny Token expanded, although it was never selected. LazyColumn uses positional identity and row expansion is remembered without a coin key.

**Impact:** Filtering or market reorder transfers interaction state between assets, which makes the interface unpredictable.

**Remedy:** Key market rows by coinId and tie saved expansion to that identity. Use stable article identity where applicable.

**Acceptance:** Expand one coin, filter it out, reorder the list, and restore it; expansion must never transfer to another coin. Retain the existing tab/search-state regression test.

### F09 Failed refreshes leave old data looking current

**Medium severity · High confidence.** [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:94](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:94), [orbital-app/src/commonMain/kotlin/io/orbital/app/App.kt:72](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/App.kt:72)

Both polling implementations discard refresh errors whenever data was previously loaded. The full-client harness changes successful market responses to 503 and waits for another poll; the old success content remains. Initial demo errors and the Retry button do work.

**Impact:** Preserving data is useful, but the user receives no stale/offline indication or explanation of why values stopped updating. Concurrent manual and automatic refreshes also have no explicit request ordering.

**Remedy:** Represent content, refresh status, last successful update, and refresh error separately. Show a non-disruptive stale indicator and retry action; cancel or serialize overlapping requests and rethrow coroutine cancellation.

**Acceptance:** Exercise initial failure, success then failure, recovery, slow overlapping requests, and tab/category cancellation. Old content may remain but its freshness must be explicit.

### F10 Small nonzero market prices are shown as zero

**Medium severity · High confidence.** [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/NumberFormat.kt:36](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/NumberFormat.kt:36)

A synthetic price of 0.00001234 is rendered as $0.00 in both clients’ shared formatter; see [demo-mobile.png](evidence/demo-mobile.png) and [full-initial.png](evidence/full-initial.png).

**Impact:** The price display loses material information for low-priced tokens, including assets within the demo’s top-100 scope.

**Remedy:** Use magnitude-aware significant digits for prices, retain normal currency precision for large amounts, and define explicit handling for nonfinite or unavailable values.

**Acceptance:** Test zero, sub-cent values, normal prices, very large values, negatives, and invalid values across JVM and WebAssembly. Nonzero valid prices must remain distinguishable from zero.

### F11 CI success is not consistently required for merge and publication

**Medium severity · High confidence.** [.github/workflows/docker-build.yml:6](/home/aldo/project/orbital/.github/workflows/docker-build.yml:6), [.github/workflows/docker-build.yml:25](/home/aldo/project/orbital/.github/workflows/docker-build.yml:25), [.github/workflows/commitlint.yml:21](/home/aldo/project/orbital/.github/workflows/commitlint.yml:21)

[github.json](evidence/github.json): the active main ruleset has an empty required_status_checks list. Legacy branch-protection reads returned 403, so total merge enforcement remains partly unverified. Docker publication runs on push independently of Test & Lint; its filters omit root build files and gradle/**; its matrix omits the ingestor. Semver tag rules exist although the workflow has no tag trigger. Commitlint checks only the last checked-out commit.

**Impact:** The visible ruleset does not name mandatory test checks; publishing can run despite failed tests, and shared dependency changes need not rebuild images. The independently runnable worker has no published image in this workflow.

**Remedy:** Require named checks, gate publication on successful validation of the same SHA, include shared build inputs and the ingestor, align release/tag triggers with intended tags, and lint the intended PR commit range or title policy.

**Acceptance:** Verify failed checks block merging under effective settings; dependency-only changes trigger all affected builds; the same validated SHA is published; worker and release artifacts exist; a multi-commit PR exercises commit policy.

### F12 Validation invokes formatters and conflicts with documentation generation

**Medium severity · High confidence.** [build.gradle.kts:37](/home/aldo/project/orbital/build.gradle.kts:37), [Makefile:34](/home/aldo/project/orbital/Makefile:34)

[gradle-validation.log](evidence/gradle-validation.log): running check and dokkaHtmlMultiModule together fails because dokkaHtmlPartial reads ktfmtFormatMain outputs without a declared dependency. check alone passes and documentation alone passes. The original source happened to be formatted already; the snapshot comparison showed no actual source formatting changes in this run.

**Impact:** A validation command can repair source before judging it, hiding formatting failures and making combined task execution invalid.

**Remedy:** Keep check/detekt read-only; remove formatter dependencies from validation and make explicit formatting a separate developer command. Correct any remaining task ordering after that separation.

**Acceptance:** A deliberately misformatted file must make check fail without changing its hash; a clean check plus docs invocation must succeed. Verify Makefile target names match their behavior.

### F13 Runtime dependencies include versions covered by security advisories

**Medium severity · High confidence.** [gradle/libs.versions.toml:10](/home/aldo/project/orbital/gradle/libs.versions.toml:10), [gradle/libs.versions.toml:29](/home/aldo/project/orbital/gradle/libs.versions.toml:29), [gradle/libs.versions.toml:24](/home/aldo/project/orbital/gradle/libs.versions.toml:24)

[dependencies-market.txt](evidence/dependencies-market.txt) resolves PostgreSQL JDBC 42.6.0, Netty HTTP/2 4.1.97.Final, and Logback 1.5.13. The applicability notes below distinguish vulnerable version ranges from demonstrated exploitability. No comprehensive dependency/container scanner was run.

**Impact:** Old transitive versions accumulate security and compatibility risk. The repo has no checked-in dependency advisory gate or update automation.

**Remedy:** Update to compatible maintained releases after checking current advisories and resolved dependency constraints. Add automated dependency review/update checks, lock or verify dependencies where appropriate, and pin critical CI/image inputs. Preserve the intentional backend/client Ktor split.

**Acceptance:** Capture a resolved inventory and scan results; classify each advisory by reachable configuration. Re-run JVM/Wasm tests, serialization contracts, image builds, and release artifacts after upgrades.

### F14 Docker sends the entire checkout into builder layers

**Medium severity · High confidence.** [gateway/Dockerfile:4](/home/aldo/project/orbital/gateway/Dockerfile:4), [market-service/Dockerfile:4](/home/aldo/project/orbital/market-service/Dockerfile:4), [news-service/Dockerfile:4](/home/aldo/project/orbital/news-service/Dockerfile:4)

There is no .dockerignore. All service builders COPY the whole context. The documented workflow creates .env in that context; local reports, build outputs, and Git metadata are also eligible for inclusion. Runtime stages copy only the JAR, so this is builder/cache exposure, not proof that secrets are in the final image.

**Impact:** Local credentials can enter build contexts and retained builder layers, and unrelated files invalidate expensive builds. Current service runtimes also use root and JAVA_OPTS is set by Compose but not consumed by the exec-form Java entrypoints.

**Remedy:** Exclude credentials, Git metadata, reports, and generated artifacts; copy only build inputs; run service images as a non-root user and use a JVM option mechanism actually read by Java.

**Acceptance:** Place a harmless sentinel file in the excluded paths and prove it is absent from the builder context/layers. Confirm runtime UID and effective heap settings. Preserve clean image builds.

### F15 Gateway and news cache entries overwrite each other

**Low severity · High confidence.** [gateway/src/main/kotlin/com/orbital/gateway/Routing.kt:216](/home/aldo/project/orbital/gateway/src/main/kotlin/com/orbital/gateway/Routing.kt:216), [news-service/src/main/kotlin/com/orbital/news/plugins/Routing.kt:83](/home/aldo/project/orbital/news-service/src/main/kotlin/com/orbital/news/plugins/Routing.kt:83)

[runtime.jsonl](evidence/runtime.jsonl): the same Redis key alternates between gateway status-plus-envelope and service article-array formats after gateway/direct-service requests. The current parsers fall back and still return a valid envelope; no corrupted response was observed.

**Impact:** Independent caching layers interfere, causing unnecessary upstream work and extra persistence under direct access or mixed traffic.

**Remedy:** Give each service/cache layer a distinct versioned namespace and normalize validated query values before constructing keys.

**Acceptance:** Interleave gateway and direct service calls; both layers must retain valid cache entries without repeated provider fetches. Test invalid and differently cased categories.

### F16 UI feedback and accessibility semantics are incomplete

**Low severity · High confidence.** [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:129](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/MarketScreen.kt:129), [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/NewsScreen.kt:68](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/NewsScreen.kt:68), [orbital-app/src/commonMain/kotlin/io/orbital/app/ui/NewsScreen.kt:146](/home/aldo/project/orbital/orbital-app/src/commonMain/kotlin/io/orbital/app/ui/NewsScreen.kt:146)

No-match search leaves an empty body ([demo-empty.png](evidence/demo-empty.png)). Browser accessibility snapshots show an unnamed textbox. Charts expose structural tables without a meaningful data summary, and expansion lacks explicit expanded/collapsed state. News cards contain a URL in the model but offer no article-opening action. Canvas pointer interaction works; semantic DOM click interception alone was not treated as an accessibility defect.

**Impact:** Users cannot distinguish an empty result from missing content, assistive technology has weak control labels, and a news-reading journey ends at a truncated card.

**Remedy:** Add visible no-results guidance, stable accessible names, expansion state, chart summaries or an accessible data alternative, and an article-opening action. Check keyboard focus order and compact layouts with long content.

**Acceptance:** Verify search names in the accessibility tree, keyboard-only search/navigation/expansion/retry, readable chart alternatives, and clear empty states. Perform manual screen-reader validation before claiming accessibility conformance.

### F17 Documentation and configuration promises diverge from the running app

**Low severity · High confidence.** [README.md:32](/home/aldo/project/orbital/README.md:32), [.env.example:13](/home/aldo/project/orbital/.env.example:13), [OVERVIEW.md:72](/home/aldo/project/orbital/OVERVIEW.md:72), [orbital-app/README.md:3](/home/aldo/project/orbital/orbital-app/README.md:3)

README says gateway Redis settings are unset, but Compose configures Redis and Sentinel. Optional gateway variables in .env.example are not forwarded by Compose. OVERVIEW’s gateway-only client statement omits the direct-provider demo. The client README describes desktop only. News “All” maps to default CRYPTO, unknown categories also become CRYPTO, and selecting a category relabels the same two mock articles. Several comments reference absent planning documents.

**Impact:** Setup expectations, architecture claims, and filter behavior do not align, which weakens reproducibility and academic presentation accuracy.

**Remedy:** Document full/demo deployment separately, wire supported configuration through Compose, and describe or correct mock-news category behavior. Reconcile README, OVERVIEW, module docs, Makefile, and comments with verified behavior.

**Acceptance:** Follow setup instructions from a clean copy; verify each documented variable reaches its intended process. Check all category/filter claims and remove or restore dangling document references.

## Dependency advisory applicability

- **PostgreSQL JDBC 42.6.0:** within the affected version range for CVE-2024-1597. The maintainer states that exploitation requires non-default `preferQueryMode=simple` and a specific parameterized-query shape. The checked-in database URLs do not enable that mode, so this review does **not** claim an exploitable SQL injection in Orbital. [Maintainer advisory](https://github.com/pgjdbc/pgjdbc/security/advisories/GHSA-24rp-q3w6-vc56).
- **Netty HTTP/2 4.1.97.Final:** predates the 4.1.100.Final Rapid Reset mitigation. Actual exploitation requires an HTTP/2 endpoint. The tested Nginx path uses HTTP/1 and HTTP/2 exposure was not established; no flooding test was performed. Upgrade planning should consider subsequent advisories as well, rather than treating that historical patch as a current safe target. [Maintainer advisory](https://github.com/netty/netty/security/advisories/GHSA-xpw8-rcwv-8f8p).
- **Logback 1.5.13:** predates the 1.5.19 conditional-configuration fix for CVE-2025-11226. The checked-in configuration uses a console encoder and no conditional expression; the runtime dependency inventory contains no Janino entry. Remote request exploitation was not demonstrated. [Maintainer release notes](https://logback.qos.ch/news.html).

## Engineering observations and review limits

The most useful clean-code improvements are explicit resource ownership and smaller behavior boundaries: close HTTP clients and connection pools on shutdown, make blocking Redis operations suspendable or dispatch them away from event-loop work, centralize error/configuration handling, and extract polling state from composables when adding freshness/cancellation behavior. Prefer these concrete changes over adopting extra architectural layers or imposing class-count/style rules.

The tests have useful assertions, but H2 persistence tests, fake Redis counters, and route-level HTTP mocks cannot establish PostgreSQL transaction behavior, Sentinel durability, or proxy client identity. No coverage percentage is claimed. New integration tests should target the failures listed above rather than mirror implementation details.

Manual screen-reader behavior, complete keyboard-only journeys, native desktop interaction, production hosting/TLS, long-duration load, sustained failover recovery, backup restoration, and exhaustive vulnerability scanning remain unverified. The Sentinel outage included TILT mode, so failover timing is inconclusive. Configured restrictive CORS was inspected but not exercised in a separate runtime instance; default wildcard behavior was observed. The existing forwarded-header tests passed. Nothing was published or changed in GitHub.

See [Remediation roadmap](ROADMAP.md) for implementation order and effort estimates. The evidence directory retains command logs, test summaries, screenshots, and runtime reproductions. The original report drafts remain outside this review.
